# script.hideosd
Hide Video On-Screen Display
